#include <stdlib.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <stdio.h>
#include <unistd.h>

int main(){
    pid_t pid;
    int retorno;
    pid = fork();
    
    if(pid < 0){
        fprintf(stderr,"Criar processo falhou \n");
        return 1;
    }
    else if (pid == 0){
        printf("Esta eh a execucao do filho (PID=%d), cujo pai tem PID=%d \n", getpid(),getppid());
        printf("Esperando...\n");
        sleep(5);
        printf("Voltou!\n");
        execlp("/bin/ls","ls","-l", NULL);
    }
    else{
        retorno = wait(NULL);
        printf("Processo-FIlho finalizou e seu pid era PID=%d \n",retorno);
        exit(0);
    }
    return 0;
}