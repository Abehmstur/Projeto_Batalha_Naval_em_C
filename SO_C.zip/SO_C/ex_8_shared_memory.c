#include <stdio.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <stdlib.h>
#include <sys/shm.h>

int = 0;
void implementacao_filho1(int *a){
    *a = *a + 1;
    printf("executando filho 1 = %d\n", getpid()); 
}
void implementacao_filho2(int *a){
    *a = *a + 2;
    printf("executando filho 2 = %d\n", getpid()); 
}

int main(){

    int filho1, filho2, pid, status;
    char *mem;

    int seg_id = shmget(IPC_PRIVATE, 20*sizeof(char), IPC_CREAT | 0666);

    filho1 = fork();
    if(filho1 == 0){
        implementacao_filho1(&a);
        mem = shmat(seg_id, NULL, 0);
        sprintf(mem, "escrita teste mem");
        printf("%s no processo PID=%d\n", mem, getpid());
        shmdt(mem);
        exit(0);
    }
    status = wait(NULL);
    if(filho1 > 0 ){
        filho2 = fork();
        if(!filho2){
            implementacao_filho2(&a);
            mem = shmat(seg_id, NULL, 0);
            printf("%s no processo PID=%d\n", mem, getpid());
            shmdt(mem);
            exit(0);
        }
    }
    status = wait(NULL);
    printf("(PID=%d) Processo sendo finalizado \n", getpid());
    printf("valor final de a=%d \n", a);
    shmctl(seg_id, IPC_RMID, NULL);
    exit(0);
    printf("O pai terminou \n")
    
    return 0;
}