#include <stdlib.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <stdio.h>
#include <unistd.h>

int main(){
    pid_t pid;

    pid = fork();
    if(pid < 0){
        fprintf(stderr,"Criar processo falhou \n");
        return 1;
    }
    else if (pid == 0){
        printf("Esta eh a execucao do filho (PID=%d), cujo pai tem PID=%d \n", getpid(),getppid());
        //for(;;);
        execlp("/bin/ls","ls","-l", NULL);
        printf("Testando execlp \n");
        exit(0);
    }
    else{
        printf("O pai esta esperando o filho \n");
        //for(;;);
        wait(NULL);
        printf("Processo-FIlho finalizou \n");
        exit(0);
    }
    return 0;
}